---
layout: mypost
title: 关于我
---

> Hello 陌生人，欢迎访问 TMaize Blog

该博客托管于 GitHub Page，国内默认解析到腾讯云，以保证国内外的访问速度。留言页面使用腾讯的“吐个槽”，另外使用的腾讯的 MTA 分析工具统计访问量

主题是自己写的，见[tmaize-blog](https://github.com/TMaize/tmaize-blog)，喜欢的话可以给个小星星。另外欢迎添加友链，在[留言板](chat.html)留言即可

## 相关技能

- 熟悉 JavaScript 语言， 熟练使用 Vue 全家桶,jQuery 等前端框架

- 熟悉 Java，NodeJs,Go 等后端语言

- 后端框架 Spring，Hibernate，JFinal，Mybatis 略有了解

- 数据库方面能熟练使用 MySQL,Oracle，MongoDB

- Linux 的简单使用，各种服务的搭建

- 能够使用 Git/SVN 对代码版本进行控制

## 联系我

- QQ&nbsp;&nbsp;&nbsp;&nbsp;: 1772314831

- Email&nbsp;: [tmaize@qq.com](http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=YBQNAQkaBSAREU4DDw0)

- GitHub: [https://github.com/tmaize](https://github.com/tmaize)
